#ifndef _XMLToolBar_h_
#define _XMLToolBar_h_

#include <Docking/Docking.h>

NAMESPACE_UPP

#define IMAGECLASS TestImg
#define IMAGEFILE <TestXMLMenu/TestXMLMenu.iml>
#include <Draw/iml_header.h>

class XMLToolBar : public DockableCtrl
{
	private:
	
		// the embedded toolbar
		ToolBar toolBar;
		
		// toolbar callback
		void toolBarCb(Bar &bar);

		// dummy callback handling toolbar items
		void dummyCb(void) {}
	
	protected:
	
	public:
	
		typedef XMLToolBar CLASSNAME;

		static Image ChCrop(const Value& element, Size canvas, Rect crop, Color baseline);
		static Image StandardHighlight(Color inside, Color border);
		static Image AlphaHighlight(const Image& img, int alpha);
		static const Style& StyleToolBar();		

		// constructor
		XMLToolBar();
		
		// destructor
		~XMLToolBar();

};

END_UPP_NAMESPACE

#endif
