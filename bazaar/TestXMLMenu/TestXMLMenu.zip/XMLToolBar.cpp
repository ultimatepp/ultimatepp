#include "XMLToolBar.h"


NAMESPACE_UPP

#define IMAGECLASS TestImg
#define IMAGEFILE <TestXMLMenu/TestXMLMenu.iml>
#include <Draw/iml_source.h>

Image XMLToolBar::ChCrop(const Value& element, Size canvas, Rect crop, Color baseline)
{
	ImageDraw draw(canvas);
	ChPaint(draw, canvas, element);	
	if (!IsNull(baseline)) {
		draw.DrawLine(0, canvas.cy-1, canvas.cx+1, canvas.cy, 1, baseline);
	}
	return Crop(draw, crop);
}

Image XMLToolBar::StandardHighlight(Color inside, Color border)
{
	Size sz(5, 5);
	ImageBuffer ib(sz);
	RGBA *q = ~ib;
	for (int i = 0; i < 5; i++)
		for (int j = 0; j < 5; j++)
			*(q++) = (i == 4 || j == 4 || !i || !j) ? border : inside;
	ib.SetHotSpot(Point(1, 1));
	ib.Set2ndSpot(Point(3, 3));
	return ib;
}

Image XMLToolBar::AlphaHighlight(const Image& img, int alpha)
{
	ImageDraw draw(img.GetSize());
	draw.Alpha().DrawRect(img.GetSize(), GrayColor(alpha));
	draw.DrawImage(0, 0, img);
	// Is there a better way to set hotspots than this?
	Image temp = (Image)draw; // GCC
	ImageBuffer ib(temp);
	ib.SetHotSpot(Point(1, 1));
	ib.Set2ndSpot(Point(3, 3));
	return ib;
}

CH_STYLE(XMLToolBar, Style, StyleToolBar)
{
	const TabCtrl::Style *style = &TabCtrl::StyleDefault();
	
	handle[0] = RotateAntiClockwise(XMLToolBar::ChCrop(style->normal[0], Size(20, 20), Rect(2, 2, 11, 20), SColorShadow)); // No focus
	handle[1] = RotateAntiClockwise(Colorize(handle[0], SColorHighlight(), 160)); // Focus
	handle_margins = Rect(0, 2, 2, 1);
	handle_vert = true;
	
	title_font = StdFont();
	title_ink[0] = SColorInfoText(); 		// No focus
	title_ink[1] = SColorHighlightText(); 	// Focus
	
/*
	DockableCtrlImgsLook(close, DockingImg::I_DClosed, 4);
	DockableCtrlImgsLook(autohide, DockingImg::I_DHided, 4);
	DockableCtrlImgsLook(pin, DockingImg::I_DPind, 4);
	DockableCtrlImgsLook(windowpos, DockingImg::I_DMenud, 4);
*/
	
	Image img = XMLToolBar::StandardHighlight(Blend(SColorHighlight, SColorPaper, 90), Blend(SColorHighlight, SBlack, 90));
	highlight[0] = img;	
	highlight[1] = XMLToolBar::AlphaHighlight(img, 160);	
}

XMLToolBar::XMLToolBar()
{
	// just for test, we fill with some items manually
	toolBar.Set(THISBACK(toolBarCb));
	Add(toolBar.SizePos());
	SetStyle(StyleToolBar());
	
}

XMLToolBar::~XMLToolBar()
{
}

void XMLToolBar::toolBarCb(Bar &bar)
{
	bar.Add(t_("New")			, TestImg::New()			, THISBACK(dummyCb));
	bar.Add(t_("NewCalc")		, TestImg::NewCalc()		, THISBACK(dummyCb));
	bar.Add(t_("Open")			, TestImg::Open()			, THISBACK(dummyCb));
	bar.Add(t_("Save")			, TestImg::Save()			, THISBACK(dummyCb));
	bar.Add(t_("SaveAs")		, TestImg::SaveAs()			, THISBACK(dummyCb));
	bar.Add(t_("JobInfo")		, TestImg::JobInfo()		, THISBACK(dummyCb));
	bar.Add(t_("PrintPreview")	, TestImg::PrintPreview()	, THISBACK(dummyCb));
	bar.Add(t_("Print")			, TestImg::Print()			, THISBACK(dummyCb));
	bar.Add(t_("Next")			, TestImg::Next()			, THISBACK(dummyCb));
	bar.Add(t_("Previous")		, TestImg::Previous()		, THISBACK(dummyCb));
	bar.Add(t_("Settings")		, TestImg::Settings()		, THISBACK(dummyCb));
	bar.Add(t_("Help")			, TestImg::Help()			, THISBACK(dummyCb));
	bar.Add(t_("Quit")			, TestImg::Quit()			, THISBACK(dummyCb));
	bar.Add(t_("Exit")			, TestImg::Exit()			, THISBACK(dummyCb));
	bar.Add(t_("Flag")			, TestImg::Flag()			, THISBACK(dummyCb));
	bar.Add(t_("Remove")		, TestImg::Remove()			, THISBACK(dummyCb));
	bar.Add(t_("Delete")		, TestImg::Delete()			, THISBACK(dummyCb));
	bar.Add(t_("ListAdd")		, TestImg::ListAdd()		, THISBACK(dummyCb));
	bar.Add(t_("ListRemove")	, TestImg::ListRemove()		, THISBACK(dummyCb));
	bar.Add(t_("RtfImport")		, TestImg::RtfImport()		, THISBACK(dummyCb));
}

END_UPP_NAMESPACE
