#include "XMLTopWindow.h"

NAMESPACE_UPP

XMLTopWindow::XMLTopWindow()
{
	DockTop(toolBar1);
	DockTop(toolBar2);
}

XMLTopWindow::~XMLTopWindow()
{
}

END_UPP_NAMESPACE
