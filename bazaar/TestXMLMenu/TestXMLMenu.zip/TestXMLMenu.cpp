#include "TestXMLMenu.h"



TestXMLMenu::TestXMLMenu()
{
	CtrlLayout(*this, "Window title");
}

GUI_APP_MAIN
{
	TestXMLMenu testXMLMenu;;
	testXMLMenu.Sizeable().Zoomable();
	testXMLMenu.Run();
}

