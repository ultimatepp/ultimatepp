#ifndef _TestXMLMenu_TestXMLMenu_h
#define _TestXMLMenu_TestXMLMenu_h

#include "XMLTopWindow.h"

using namespace Upp;

#define LAYOUTFILE <TestXMLMenu/TestXMLMenu.lay>
#include <CtrlCore/lay.h>



class TestXMLMenu : public WithTestXMLMenuLayout<XMLTopWindow>
{
	public:
		typedef TestXMLMenu CLASSNAME;

		TestXMLMenu();
};

#endif

