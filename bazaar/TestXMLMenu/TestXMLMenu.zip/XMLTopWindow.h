#ifndef _XMLTopWindow_h_
#define _XMLTopWindow_h_

#include "XMLToolBar.h"

NAMESPACE_UPP

class XMLTopWindow : public DockWindow
{
	private:

		XMLToolBar toolBar1, toolBar2;
	
	protected:
	
	public:
	
		typedef XMLTopWindow CLASSNAME;
		
		XMLTopWindow();
		~XMLTopWindow();
};

END_UPP_NAMESPACE

#endif
