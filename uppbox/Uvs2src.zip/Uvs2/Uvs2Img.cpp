#include "Uvs2.h"
#pragma hdrstop

#include "Uvs2Img.h"
#define IMAGECLASS Uvs2Img
#define IMAGEFILE <Uvs2/Uvs2.iml>
#include <Draw/iml_source.h>
