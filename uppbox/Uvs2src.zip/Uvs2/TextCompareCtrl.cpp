#include "Uvs2.h"
#pragma hdrstop

class TextCompareCtrl : public Ctrl {
public:
	typedef TextCompareCtrl CLASSNAME;
	TextCompareCtrl();

};
