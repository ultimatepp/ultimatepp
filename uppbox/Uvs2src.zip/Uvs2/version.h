#ifndef __uvs_version__
#define __uvs_version__

#define UVS2_VERSION   "2.40"
#define UVS2_DATE      Date(2007, 10, 30)
#define UVS2_COPYRIGHT "Copyright � 2002-2007 Ultimate Development, spol. s r.o."

#endif
