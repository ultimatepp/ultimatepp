#ifndef __Uvs2__
#define __Uvs2__

#include <CtrlLib/CtrlLib.h>
#include <Web/Web.h>
#include <plugin/ftp/ftp.h>

using namespace Upp;

//#include "wininet.h"
#include "util.h"

#endif
