#ifndef __uvs2_Uvs2Img__
#define __uvs2_Uvs2Img__

#define IMAGECLASS Uvs2Img
#define IMAGEFILE <Uvs2/Uvs2.iml>
#include <Draw/iml_header.h>

#endif
